const API_KEY = "f8d2004b"; 
const BASE_URL = "http://www.omdbapi.com/";


export const getPopularMovies = async () => {
  const response = await fetch(`${BASE_URL}?apikey=${API_KEY}&s=avengers`);
  const data = await response.json();

  if (data.Response === "True") {
    return data.Search; 
  } else {
    throw new Error(data.Error || "Failed to fetch popular movies");
  }
};


export const searchMovies = async (query) => {
  const response = await fetch(
    `${BASE_URL}?apikey=${API_KEY}&s=${encodeURIComponent(query)}`
  );
  const data = await response.json();

  if (data.Response === "True") {
    return data.Search;
  } else {
    throw new Error(data.Error || "Failed to search movies");
  }
};
